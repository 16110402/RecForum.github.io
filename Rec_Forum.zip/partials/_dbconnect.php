<?php

$servername="localhost";
$username="root";
$password="";
$database="rec forum";

$conn=mysqli_connect($servername,$username,$password,$database);

?>
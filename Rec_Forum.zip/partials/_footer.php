<div class="container-fluid bg-light text-light">
<p class="container text-center mb-0" style="color: white;background-color:blueviolet;text-align: center;border:4px solid;border-radius:10px;border-color: lightblue;width: 340px;">Copyright iDiscuss Coding Forums 2021 | All rights reserved</p>
</div>